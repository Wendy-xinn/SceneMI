"""Audit actual native30 inputs and full model gradients; zero optimizer steps."""
import argparse
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import torch

from experiments.offline_camera_retrain_v1.data import HERE
from experiments.offline_camera_retrain_v1.native30_data import Native30Data
from experiments.offline_camera_retrain_v1.native30_observations import Native30ObservationBuilder,inference_payload,load_frozen_exo,load_frozen_ego
from experiments.offline_camera_retrain_v1.native30_model import Native30SceneMI,reconcile_motion
from experiments.offline_camera_retrain_v1.native30_refinement import Native30Refinement,model_inputs,sample_motion
from experiments.offline_camera_retrain_v1.native30_losses import base_losses,observation_losses,objective
from experiments.offline_camera_retrain_v1.native30_preview import preview
from experiments.offline_camera_retrain_v1.native30_assets import Native30SkinAnchorCache
from experiments.offline_camera_retrain_v1.unified_observations import collate_observations
from experiments.offline_camera_retrain_v1.supervision import forward_kinematics,PARENTS
from experiments.offline_camera_retrain_v1.scene_model import cosine_alphas
from experiments.offline_camera_retrain_v1.native30_cache_io import atomic_text,mapped_sha256,verified_sha256

CONFIG_PATH=HERE/'native30_recording_headonly_config.json'


def sha256(path):
    return mapped_sha256(path)


def write_json(path,value):
    atomic_text(path,json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')


def code_hashes():
    # Record the actual imported repository dependencies, plus the trainer
    # which preparation must never import/execute as a side effect.
    paths=set(HERE.glob('*.py'))|set((HERE.parents[1]/'model').rglob('*.py'))
    from vit_pytorch import vit
    paths.add(Path(vit.__file__))
    paths.add(HERE.parents[2]/'diffusion-motion-inbetweening/sample/virtual_head_camera.py')
    return {str(p.resolve()):sha256(p) for p in sorted(paths)}


def read_config(path=CONFIG_PATH):
    config=json.loads(Path(path).read_text())
    if config.get('diffusion_target','absolute_x0') not in ('absolute_x0','reference_residual'):
        raise ValueError('Unknown native30 diffusion target')
    from experiments.offline_camera_retrain_v1.unified_losses import SCALES
    if config['fps']!=30 or config['frames']!=192 or config['initialization'] not in ('from_scratch','official30_warm_start'):
        raise ValueError('Expected fresh native30 /192 frame configuration')
    if config['initialization']=='from_scratch' and 'warm_start' in config:
        raise ValueError('Fresh training must not declare a warm-start checkpoint')
    if config['shared_output_initialization']!='normal_std_0.001_bias_zero' or config['anchor_protocol']!='native_body_dominant_only_67_low_foot_v1':
        raise ValueError('Shared output/anchor initialization differs from implementation')
    if set(config['observation']['scales'])!=set(SCALES) or any(not np.isfinite(v) or v<=0 for v in config['observation']['scales'].values()):
        raise ValueError('Observation scales must be positive finite physical values')
    importance=config['observation']['joint_weights']
    if len(importance)!=22 or any(not np.isfinite(v) or v<=0 for v in importance):raise ValueError('Invalid observation joint weights')
    from experiments.offline_camera_retrain_v1.native30_input_noise import validate_input_noise
    from experiments.offline_camera_retrain_v1.native30_gt_reliability import validate_gt_reliability
    validate_input_noise(config['observation']['input_noise']);validate_gt_reliability(config['gt_reliability'])
    if config['validation']['interval_steps']<1 or config['validation']['members_per_group_mode']<1:
        raise ValueError('Validation cadence and scope must be positive')
    if config['validation']['regimes']!=['clean','noisy']:
        raise ValueError('Registered validation reports clean and noisy inputs separately')
    if config['validation'].get('subset_protocol'):
        from experiments.offline_camera_retrain_v1.native30_validation import SUBSET_PROTOCOL
        options=config['validation']
        if options['subset_protocol']!=SUBSET_PROTOCOL or config['ego_head_only_probability']!=1:
            raise ValueError('Rotating monitoring requires the registered head-only protocol')
        for key in ('fixed_recordings_per_dataset_mode','rotating_recordings_per_dataset_mode'):
            if isinstance(options[key],bool) or not isinstance(options[key],int) or options[key]<1:
                raise ValueError('Validation panel sizes must be positive integers')
        cadence=options.get('scene_ablation_interval_steps',0)
        if isinstance(cadence,bool) or not isinstance(cadence,int) or cadence<0 or cadence%options['interval_steps']:
            raise ValueError('Scene checks must follow the monitoring interval')
    if config['scene']['scales_m']!=[.08,.25,.6] or config['scene']['patch_tokens']!=16 or config['scene']['neighbors_per_scale']!=8:
        raise ValueError('Scene representation differs from current implementation')
    from experiments.offline_camera_retrain_v1.native30_splits import SPLIT_PROTOCOL
    from experiments.offline_camera_retrain_v1.native30_memory import MEMORY_PROTOCOLS
    if config.get('split_protocol')!=SPLIT_PROTOCOL or config['scene'].get('memory_protocol') not in MEMORY_PROTOCOLS:
        raise ValueError('Official splits and cross-window observed memory must be configured explicitly')
    if config['noise']['steps']!=1000 or config['noise']['low_noise_steps']>1000:
        raise ValueError('Feedback schedule requires the registered cosine1000 clock')
    if not 0<config['ego_probability']<1 or not 0<=config['ego_head_only_probability']<=1:
        raise ValueError('Invalid sampling probabilities')
    if config.get('sampler'):
        from experiments.offline_camera_retrain_v1.native30_sampling import validate_sampling_options
        mode=config.get('training_mode')
        if mode not in (None,'ego','exo'):raise ValueError('Unknown training stage')
        validate_sampling_options(config['sampler'],1. if mode=='ego' else 0. if mode=='exo' else config['ego_probability'])
    if config['batch_size']<1 or config['optimizer']['lr']<=0:
        raise ValueError('Invalid batch size/learning rate')
    limit=config.get('exo_max_empty_frames')
    if limit is not None and (isinstance(limit,bool) or not isinstance(limit,int) or limit<0):
        raise ValueError('exo_max_empty_frames must be a nonnegative integer or null')
    stride=config.get('window_stride',1)
    if isinstance(stride,bool) or not isinstance(stride,int) or stride<1:
        raise ValueError('window_stride must be a positive integer')
    if stride!=1 and not config.get('window_index'):
        raise ValueError('Nonlegacy training needs its persisted window index')
    if not 2<=config['sampling']['ddim_steps']<=1000:
        raise ValueError('DDIM inference steps outside supported schedule')
    if config.get('scene_relations',{}).get('enabled'):
        relations=config['scene_relations'];guidance=config['physical_guidance']
        if relations['neighbors']!=4 or relations['radius_m']<=0 or relations['support_radius_m']<=0 or relations['gain']<0:
            raise ValueError('Invalid metric relation query configuration')
        if not 0<guidance['contact_threshold']<1 or guidance['iterations']<1 or not 0<=guidance['minimum_alpha']<=1:
            raise ValueError('Invalid physical guidance schedule')
        for key in ('translation_step_m','rotation_step_rad','root_total_limit_m','trusted_tolerance_m','query_limit_m'):
            if not np.isfinite(guidance[key]) or guidance[key]<=0:raise ValueError(f'Invalid physical limit: {key}')
    return config


def window_options(config,full_data=True):
    result=dict(window_stride=config.get('window_stride',1))
    if config.get('runtime',{}).get('canonical_surface_cache'):
        result['canonical_surface_cache']=True
    if full_data and config.get('window_index'):
        result['window_index']=HERE/config['window_index']
    return result


def training_plan(data, config):
    plan=data.sampling_plan(config['ego_probability'])
    if config.get('training_mode'):
        plan=[row.copy() for row in plan if row['mode']==config['training_mode']]
        total=sum(row['probability'] for row in plan)
        for row in plan:row['probability']/=total
    return plan


def make_model(config):
    if config.get('scene_relations',{}).get('enabled'):
        from experiments.offline_camera_retrain_v1.native30_scene_relations import Native30SceneRelations
        return Native30SceneRelations(config['latent_dim'],tuple(config['dim_mults']),
            **{k:config.get('refinement',{}).get(k,0.) for k in ('observation_anchor_gain','joint_anchor_gain')},
            **{k:config['feedback'][k] for k in ('root_limit_m','rotation_limit_rad','feedback_gain')},
            relations=config['scene_relations'],guidance=config['physical_guidance'])
    model_type=Native30Refinement if config.get('diffusion_target','absolute_x0')=='reference_residual' else Native30SceneMI
    extra={k:config.get('refinement',{}).get(k,0.) for k in ('observation_anchor_gain','joint_anchor_gain')} if model_type is Native30Refinement else {}
    return model_type(config['latent_dim'],tuple(config['dim_mults']),**extra,**{k:config['feedback'][k]
        for k in ('root_limit_m','rotation_limit_rad','feedback_gain')})


def dataset_digest(data):
    report={str(data.manifest.resolve()):sha256(data.manifest)}
    for path in data.window_index_files:
        report[str(Path(path).resolve())]=sha256(path)
    from experiments.offline_camera_retrain_v1.native30_splits import OFFICIAL_CSV, SPLITS
    from experiments.offline_camera_retrain_v1.data import SOURCE
    for path in [OFFICIAL_CSV,SOURCE/'sequences.jsonl']+[SOURCE/f'{g}_sequences/{s}.jsonl' for g in ('egobody','trumans') for s in SPLITS]:
        report[str(path.resolve())]=sha256(path)
    # Skinning depends on immutable native templates/weights too, rather than
    # only cached rest joints. Future training checks the same fingerprints.
    body_paths=list((HERE.parents[1]/'body_models/smplx').glob('SMPLX_*.*'))
    body_paths+=list((HERE.parents[2]/'ProtoMotions/data/smpl').glob('SMPL_*.pkl'))
    for path in body_paths:
        if path.suffix in ('.npz','.pkl'):report[str(path.resolve())]=sha256(path)
    # Even a short source with no motion-training window can contribute static
    # observations to a longer recording. Include all memory dependencies.
    for meta in data.scene_memory.entries:
        folder=Path(meta['path']); report[str((folder/'metadata.json').resolve())]=sha256(folder/'metadata.json')
        for filename,digest in meta['output_sha256'].items():
            verified_sha256(folder/filename,digest)
    return report


def sample_item(data,builder,config,plan,rng):
    if config.get('sampler'):
        from experiments.offline_camera_retrain_v1.native30_sampling import StratifiedRecordingSampler
        if not hasattr(data,'training_sampler'):
            data.training_sampler=StratifiedRecordingSampler(data,plan,config['sampler'],config['seed']+371)
        row=data.training_sampler.draw()
        sample,identity=data.sample(row['group'],row['mode'],member=row['member'],start=row['start'])
        identity['sampling']=dict(protocol=config['sampler']['protocol'],**{k:row[k] for k in ('recording_key','cooldown_fallback','overlap_fallback')})
    else:
        ix=int(rng.choice(len(plan),p=[r['probability'] for r in plan]));row=plan[ix]
        sample,identity=data.sample(row['group'],row['mode'])
    joints=None if row['mode']=='exo' else ((15,) if rng.random()<config['ego_head_only_probability'] else (15,20,21))
    sample,scene,asset=builder.build(data,sample,identity,row['mode'],joints,noise_rng=rng)
    if config.get('scene_relations',{}).get('enabled') and data.split=='train':
        if config.get('runtime',{}).get('precomputed_support'):
            from experiments.offline_camera_retrain_v1.native30_support_cache import cached_support
            sample=cached_support(data,builder,sample,identity)
        else:
            from experiments.offline_camera_retrain_v1.native30_scene_support import attach_support_supervision
            sample=attach_support_supervision(sample,scene,asset)
    return (sample,scene,asset,row['mode']),identity


def export_review(config):
    from experiments.offline_camera_retrain_v1.native30_export import export,inventory
    folder=(HERE/config['review_manifest']).parent;folder.mkdir(parents=True,exist_ok=True)
    audit=json.loads((HERE/'runs/ego_exo_retrain_design_oct12/READONLY_HEAD_AUDIT.json').read_text())
    result=[]
    for entry in audit['rows']:
        row=next(r for r in inventory(entry['split'],split_protocol='legacy-internal-scene-v1') if r['sequence_id']==entry['sequence_id'])
        result.append(export(row,folder,start=int(entry['source_start_30fps']),frames=config['frames']))
        temp=folder/'manifest.tmp';temp.write_text(''.join(json.dumps(r)+'\n' for r in result));temp.replace(folder/'manifest.jsonl')
    write_json(folder/'review_scope.json',dict(diagnostic_only=True,full_training_coverage=False,
               raw30_windows=len(result),frames=config['frames'],optimizer_steps=0))


def run(config_path=CONFIG_PATH,*,full_data=False,export_inputs=False):
    config=read_config(config_path)
    if export_inputs:export_review(config)
    folder=HERE/config['prepared_output'];folder.mkdir(parents=True,exist_ok=True)
    report=dict(status='running',optimizer_steps=0,data_mode='full' if full_data else 'review',
                training_started=False,free_disk_before=shutil.disk_usage(HERE).free,checks={})
    write_json(folder/'input_checks.json',report);started=time.monotonic()
    torch.set_num_threads(4);torch.manual_seed(config['seed']);np.random.seed(config['seed'])
    manifest=HERE/config['train_manifest' if full_data else 'review_manifest']
    memory_protocol=config['scene']['memory_protocol']
    data=Native30Data(manifest,'train',config['seed'],diagnostic=not full_data,frames=config['frames'],memory_protocol=memory_protocol,quality_config=config['gt_reliability'],exo_max_empty_frames=config.get('exo_max_empty_frames'),**window_options(config,full_data))
    validation=Native30Data(manifest,'validation',config['seed']+1,diagnostic=not full_data,frames=config['frames'],memory_protocol=memory_protocol,quality_config=config['gt_reliability'],exo_max_empty_frames=config.get('exo_max_empty_frames'),**window_options(config,full_data))
    from experiments.offline_camera_retrain_v1.native30_validation import fixed_plan
    from experiments.offline_camera_retrain_v1.native30_validation import monitoring_plan
    validation_plan=monitoring_plan(validation,config,1)
    write_json(folder/'validation_plan.json',dict(seed=config['validation']['seed'],plan=validation_plan,
        GT_metrics_unweighted=True,regimes=config['validation']['regimes'],
        ddim_steps=config['sampling']['ddim_steps'],optimizer_steps=0,evaluation_run=False))
    report['checks']['fixed_validation_plan']=dict(cases=len(validation_plan),
        clean_noisy_evaluations=2*len(validation_plan),split='validation',test_tuning=False)
    mount_path=HERE/config['mount_defaults' if full_data else 'diagnostic_mount_defaults']
    mounts=json.loads(mount_path.read_text());skins=Native30SkinAnchorCache()
    if full_data:
        from experiments.offline_camera_retrain_v1.native30_splits import SPLIT_PROTOCOL, OFFICIAL_CSV, official_recordings
        for mount in mounts.values():
            records=mount.get('fitting_recordings',[])
            if mount.get('split_protocol')!=SPLIT_PROTOCOL or mount.get('official_split_csv_sha256')!=sha256(OFFICIAL_CSV) or not records:
                raise ValueError('Refit camera mounts on official TRAIN and record calibration provenance')
            if any(official_recordings().get(r)!='train' for r in records):
                raise ValueError('Camera mount calibration contains official val/test recordings')
    builder=Native30ObservationBuilder(skins,mounts,config['observation']['input_noise']);cases=[];train_cases=[];alignment=[]
    for source in (data,validation):
        for group in source.members:
            for mode in ('ego','exo'):
                mi=next((i for i,(meta,_) in enumerate(source.members[group]) if mode in meta.get('allowed_modes',['ego','exo']) and len(source.starts_for(group,i,mode))),None)
                if mi is None:continue
                sample,identity=source.sample(group,mode,member=mi,start=int(source.starts_for(group,mi,mode)[0]),yaw=0)
                sample,scene,asset=builder.build(source,sample,identity,mode,joints=None)
                if config.get('scene_relations',{}).get('enabled') and source.split=='train':
                    from experiments.offline_camera_retrain_v1.native30_scene_support import attach_support_supervision
                    sample=attach_support_supervision(sample,scene,asset)
                item=(sample,scene,asset,mode);label=f'{source.split}/{group}/{mode}'
                cases.append((label,item,identity))
                if source.split=='train':train_cases.append((label,item,identity))
                motion=torch.from_numpy(sample['motion'][None]);fk=forward_kinematics(motion,torch.from_numpy(sample['rest'][None]))[0].numpy()
                discrepancy=float(np.abs(fk-sample['joints']*2).max())
                if discrepancy>1e-4:raise AssertionError(f'Native GT/FK mismatch: {label}, {discrepancy}')
                available=sample['observation_meta'][...,0]>0
                errors=np.linalg.norm(sample['trajectory'][...,:3]*2-sample['joints']*2,axis=-1)
                head_error=float(errors[:,15].mean()) if mode=='ego' else None
                if mode=='ego' and group!='camera_wearer' and head_error>1e-4:
                    raise AssertionError('Actual virtual mount does not recover native head')
                if mode=='exo' and sample['observation_meta'][...,1].any():raise AssertionError('GT rotation leaked into exo')
                alignment.append(dict(label=label,source=identity['source_start_30fps'],frames=192,fps=30,
                    maximum_native_fk_m=discrepancy,head_inverse_mean_m=head_error,
                    reliable_position_mean=float(available.sum(-1).mean()),static_points=len(scene.points),
                    current_dynamic_points_mean=float(np.mean([len(c['points']) for c in scene.dynamic])),
                    contact_label_entries=int(sample['contact_valid'].sum())))
    preview(cases,folder);write_json(folder/'alignment_checks.json',alignment)
    model=make_model(config).cuda().eval();torch.cuda.reset_peak_memory_stats()
    checks=report['checks'];calibration=[];alphas=cosine_alphas().cuda()
    from scipy.spatial.transform import Rotation
    yaw_rotation=Rotation.from_rotvec([0,.6,0]).as_matrix();yaw_error=0.
    for label,item,identity in cases:
        source=data if identity['split']=='train' else validation
        mi=next(i for i,(meta,_) in enumerate(source.members[identity['group']]) if meta['path']==identity['path'])
        altered,_=source.sample(identity['group'],identity['mode'],member=mi,start=identity['start'],yaw=.6)
        expected=(item[0]['joints']*2)@yaw_rotation.T
        yaw_error=max(yaw_error,float(np.abs(altered['joints']*2-expected).max()))
    if yaw_error>1e-5:raise AssertionError('Post-anchor world yaw is inconsistent or cancelled')
    checks['post_anchor_common_world_yaw']=dict(angle_rad=.6,maximum_joint_error_m=yaw_error)
    for label,item,identity in train_cases:
        batch=collate_observations([item]);known=model_inputs(config,batch)
        state=torch.randn_like(batch['motion']);t=torch.tensor([25],device='cuda')
        with torch.no_grad():prediction,details=model(state,t,known,return_details=True)
        checks.setdefault('predicted_proposal_query_coverage',[]).append(dict(label=label,
            known_anchor_fraction=float(torch.cat([g['closest_valid'].flatten() for g in details['geometry']]).float().mean()),
            known_region_fraction=float(torch.cat([g['region_valid'].flatten() for g in details['geometry']]).float().mean()),
            query_source='untrained predicted x0, no GT skin queries'))
        for timestep in (25,300,800):
            signal=alphas[torch.tensor([timestep],device='cuda')]
            leaf=prediction.detach().requires_grad_(True)
            base=base_losses(leaf,batch['motion'],batch,signal,details['raw_motion'].detach())['total']
            terms=observation_losses(leaf,batch['motion'],batch,signal,config['observation'])
            reference=float(torch.autograd.grad(base,leaf,retain_graph=True)[0].norm())
            row=dict(label=label,timestep=timestep,reference_gradient_norm=reference,terms={})
            for key,value in terms.items():
                gradient=torch.autograd.grad(value,leaf,retain_graph=True)[0]
                if not torch.isfinite(gradient).all():raise AssertionError(f'Nonfinite observation gradient: {label}/{key}')
                row['terms'][key]=dict(loss=float(value.detach()),gradient_norm=float(gradient.norm()))
            calibration.append(row)
        print('audited TRAIN gradient bucket',label,flush=True)
    targets=config['observation']['target_gradient_ratios'];caps=config['observation']['maximum_coefficients']
    weights={}
    # Conservative across domains and noise buckets; unavailable rotations do
    # not dilute gradients of streams that actually provide rotation evidence.
    for key in targets:
        ratios=[r['terms'][key]['gradient_norm']/max(r['reference_gradient_norm'],1e-12)
                for r in calibration if r['terms'][key]['gradient_norm']>0]
        weights[key]=min(caps[key],targets[key]/max(ratios)) if ratios else 0.
    for row in calibration:
        for key,term in row['terms'].items():
            term['coefficient']=weights[key]
            term['weighted_gradient_ratio']=weights[key]*term['gradient_norm']/max(row['reference_gradient_norm'],1e-12)
    write_json(folder/'TRAIN_gradient_scales.json',dict(fitting_split='train',panel_windows=len(train_cases),
        noise_buckets=[25,300,800],method='cap maximum weighted shared-output gradient ratio across available buckets',
        not_population_calibration=True,coefficients=weights,buckets=calibration,
        geometry_coefficients_status='conservative initial values; finite-gradient check, not efficacy calibration'))
    # Actual batch2 full-objective backward, no optimizer constructed or stepped.
    exo=next(item for label,item,_ in train_cases if label=='train/camera_wearer/exo')
    rich=next(item for label,item,_ in train_cases if label=='train/rich/ego')
    items=[exo,rich][:config['batch_size']]
    while len(items)<config['batch_size']:items.append(exo)
    batch=collate_observations(items);known=model_inputs(config,batch);t=torch.full((len(items),),25,device='cuda')
    signal=alphas[t];state=torch.randn_like(batch['motion'])
    model.train();prediction,details=model(state,t,known,return_details=True)
    loss,terms=objective(prediction,batch['motion'],batch,signal,details,config,weights)
    loss.backward()
    gradients={name:float(p.grad.norm()) for name,p in model.named_parameters() if p.grad is not None}
    if not torch.isfinite(loss) or not all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None):
        raise AssertionError('Nonfinite complete objective/parameter gradients')
    for name in ('root_feedback.weight','rotation_feedback.weight'):
        if gradients.get(name,0)<=0:raise AssertionError(f'Missing positional/SO3 feedback gradient: {name}')
    condition_names=('observation_encoder.0.weight','camera_encoder.0.weight','patch_projection.weight','dynamic_condition.weight',
                     'patch_condition.weight','surface_embedding.0.weight','region_condition.weight','contact_pose.0.weight')
    for name in condition_names:
        if gradients.get(name,0)<=0:raise AssertionError(f'Missing condition gradient: {name}')
    checks['full_objective_backward']=dict(batch_size=len(items),frames=192,finite=True,optimizer_steps=0,
        loss=float(loss.detach()),root_feedback_gradient_norm=gradients['root_feedback.weight'],
        rotation_feedback_gradient_norm=gradients['rotation_feedback.weight'],
        peak_cuda_gib=torch.cuda.max_memory_allocated()/2**30,
        condition_gradient_norms={k:gradients[k] for k in condition_names},
        zero_initialized_feedback_upstream_gradients='temporal/contact path initially waits for zero residual heads to learn')
    model.zero_grad(set_to_none=True);model.eval()
    # Independent frozen loader cannot read GT motion/contact even accidentally.
    item=exo;label,_,identity=next(x for x in train_cases if x[0]=='train/camera_wearer/exo')
    baseline=collate_observations([item]);known=model_inputs(config,baseline)
    checked_exo=[]
    for case_label,case_item,case_identity in cases:
        if case_item[3]!='exo':continue
        expected=inference_payload(collate_observations([case_item]))
        frozen=load_frozen_exo(case_identity['path'],start=case_identity['start'],skin_cache=skins,memory_manifest=manifest,memory_protocol=memory_protocol)
        for key in ('trajectory','observation_meta','camera','occupancy'):
            if not torch.equal(expected[key],frozen[key]):raise AssertionError(f'Frozen observations differ: {case_label}/{key}')
        checked_exo.append(case_label)
    checks['frozen_no_body_truth_loader']=dict(passed=True,cases=checked_exo)
    for label,item,identity in cases:
        if item[3]!='ego':continue
        expected=inference_payload(collate_observations([item]))
        actual=load_frozen_ego(identity['path'],start=identity['start'],skin_cache=skins,mounts=mounts,memory_manifest=manifest,memory_protocol=memory_protocol)
        for key in ('trajectory','observation_meta','camera','occupancy'):
            if not torch.equal(expected[key],actual[key]):raise AssertionError(f'Frozen self input mismatch: {label}/{key}')
    checks['frozen_self_camera_head_without_body_truth']=True
    state=torch.randn_like(baseline['motion']);t=torch.tensor([25],device='cuda')
    with torch.no_grad():
        y,d=model(state,t,known,return_details=True)
        poison=dict(known,motion=torch.full_like(y,float('nan')),joints=torch.full_like(baseline['joints'],float('nan')))
        yp=model(state,t,poison)
        if not torch.equal(y,yp):raise AssertionError('Hidden body truth affects forward')
        checks['hidden_truth_poison']=True
        masked=dict(known,trajectory=torch.zeros_like(known['trajectory']),observation_meta=known['observation_meta'].clone(),
                    camera_confidence=torch.zeros_like(known['camera_confidence']))
        masked['observation_meta'][...,:4]=0
        pm=model(state,t,masked)
        masked_poison=dict(masked,trajectory=torch.full_like(masked['trajectory'],float('nan')),camera=torch.full_like(masked['camera'],float('nan')))
        mp=model(state,t,masked_poison)
        if not torch.equal(pm,mp):raise AssertionError('Zero-confidence observations leaked through a route')
        checks['zero_confidence_poison_all_paths']=True
        # Demonstrate the residual mechanism with temporary, explicit test
        # parameters; restore them and do not save as learned weights.
        # An untrained body can be too far from all real surfaces. Build a
        # controlled observed plane around its own predicted feet, without GT.
        from experiments.offline_camera_retrain_v1.native30_geometry import Native30SurfaceWindow
        from experiments.offline_camera_retrain_v1.unified_geometry import skin_points,occupancy_from_points
        vertices=skin_points(d['proposal'][0],known['skin_assets'][0])
        foot=vertices[:,torch.isin(known['skin_assets'][0]['labels'],vertices.new_tensor([10,11],dtype=torch.long))].mean((0,1)).cpu().numpy()
        grid=np.linspace(-.65,.65,23)
        plane_points=np.array([[foot[0]+x,foot[1]-.03,foot[2]+z] for x in grid for z in grid],np.float32)
        controlled=Native30SurfaceWindow(np.broadcast_to(plane_points,(192,*plane_points.shape)),
            np.zeros((192,len(plane_points)),np.int32),np.tile(foot+[0,.5,0],(192,1)))
        feedback_known=dict(known,surface_windows=[controlled],
            occupancy=torch.from_numpy(occupancy_from_points(plane_points))[None].cuda())
        saved={k:model.state_dict()[k].clone() for k in ('root_feedback.bias','rotation_feedback.bias')}
        model.root_feedback.bias.fill_(.35);model.rotation_feedback.bias.fill_(.2)
        corrected,cd=model(state,t,feedback_known,return_details=True)
        for k,v in saved.items():model.state_dict()[k].copy_(v)
        body=forward_kinematics(corrected,baseline['rest'])
        root_change=float(cd['root_delta_m'].norm(dim=-1).max())
        position_change=float((body-forward_kinematics(reconcile_motion(cd['raw_motion'],baseline['rest']),baseline['rest'])).norm(dim=-1).max())
        if root_change<=0 or position_change<=0:raise AssertionError('Contact feedback does not change position')
        bone_error=0.
        for j in range(1,22):
            length=(body[:,:,j]-body[:,:,PARENTS[j]]).norm(dim=-1)
            rest_length=(baseline['rest'][:,j]-baseline['rest'][:,PARENTS[j]]).norm(dim=-1)[:,None]
            bone_error=max(bone_error,float((length-rest_length).abs().max()))
        fk_error=float((corrected[...,135:].reshape(1,192,22,3)*2-body).abs().max())
        if bone_error>1e-5 or fk_error>1e-6:raise AssertionError('Position feedback breaks native skeleton consistency')
        checks['position_rotation_feedback']=dict(test_parameters_only=True,root_delta_max_m=root_change,
            joint_position_change_max_m=position_change,bone_length_error_max_m=bone_error,fk_branch_error_max_m=fk_error,
            geometry='controlled observed plane at untrained predicted feet; no GT body query',real_motion_quality_claim=False)
        # Suppressing predicted contact must suppress positional feedback,
        # including biases in temporal layers and output projections.
        contact_bias=model.contact_readout.bias.clone();root_bias=model.root_feedback.bias.clone()
        model.root_feedback.bias.fill_(.35);model.contact_readout.bias.fill_(-100.)
        _,suppressed=model(state,t,feedback_known,return_details=True)
        model.root_feedback.bias.copy_(root_bias);model.contact_readout.bias.copy_(contact_bias)
        if suppressed['root_delta_m'].abs().max()>1e-10:
            raise AssertionError('Temporal/output bias bypasses contact gating')
        checks['contact_gate_controls_position_feedback']=True
        no_scene=model(state,t,known,use_scene=False)
        scene_difference=float((y-no_scene).abs().max())
        if scene_difference<=0:raise AssertionError('Scene has no connection to output')
        checks['scene_condition_reaches_output']=dict(maximum_difference=scene_difference,quality_claim=False)
        model.patch_enabled=False;without_patch=model(state,t,known);model.patch_enabled=True
        checks['patch_condition_reaches_output']=dict(maximum_difference=float((y-without_patch).abs().max()),quality_claim=False)
        if checks['patch_condition_reaches_output']['maximum_difference']<=0:
            raise AssertionError('Patch tokens do not affect the actual output')
        controlled_output=model(state,t,feedback_known)
        model.local_enabled=False;without_local=model(state,t,feedback_known);model.local_enabled=True
        checks['local_condition_reaches_output']=dict(maximum_difference=float((controlled_output-without_local).abs().max()),
            geometry='controlled observed plane',quality_claim=False)
        if checks['local_condition_reaches_output']['maximum_difference']<=0:
            raise AssertionError('Local geometry does not affect the actual output')
        sample=sample_motion(model,known,config,steps=2,seed=config['seed'])
        if not torch.isfinite(sample).all():raise AssertionError('Nonfinite complete-window DDIM inference')
        checks['full_window_ddim_smoke']=dict(frames=192,steps=2,core_forwards=4,finite=True,
            quality_claim=False,normal_evaluation_steps=config['sampling']['ddim_steps'],static_tokens_reused=True)
        if model._sampling_scene is not None:raise AssertionError('Stale sampling tokens survived generation')
    report.update(status='passed',elapsed_s=time.monotonic()-started,training_ready=bool(full_data),
        data_scope='full corpus' if full_data else '8 raw30 review clips; 12 ego/exo input cases; full-corpus export pending',
        free_disk_after=shutil.disk_usage(HERE).free,model_parameters=sum(p.numel() for p in model.parameters()),
        alignment=alignment)
    # Keep the actual model checks if an external drive disappears while the
    # final data fingerprints are being sealed. This does not authorize training.
    write_json(folder/'model_checks.json',dict(report,status='numeric_checks_passed',
        training_ready=False,fingerprints_complete=False))
    try:
        fingerprints=dataset_digest(data)|dataset_digest(validation)
    except (OSError,ValueError) as exc:
        report.update(status='numeric_checks_passed_fingerprint_failed',training_ready=False,
            fingerprints_complete=False,fingerprint_error=repr(exc))
        write_json(folder/'input_checks.json',report)
        raise
    effective=dict(config=config,data_mode=report['data_mode'],sampling_plan=training_plan(data,config),
        observation_coefficients=weights,mount_defaults_sha256=sha256(mount_path),
        data_sha256=fingerprints,code_sha256=code_hashes(),torch_version=torch.__version__,
        normalization='motion positions m/2; physical derivatives SI',optimizer_steps=0)
    write_json(folder/'effective_config.json',effective);write_json(folder/'input_checks.json',report)
    print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=CONFIG_PATH)
    parser.add_argument('--full-data',action='store_true')
    parser.add_argument('--export-review',action='store_true')
    args=parser.parse_args();run(args.config,full_data=args.full_data,export_inputs=args.export_review)
